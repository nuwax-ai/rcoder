#!/bin/sh
printf legacy-zip8
